
# 📦 Pack outil – JusticeDMJ972Project

Ce dossier contient :
- `menu_template.html` : modèle de menu multilingue
- `injecteur_menu.py` : script Python qui injecte le menu dans toutes les pages .html du dossier
- `README.md` : guide d'utilisation

## 📜 Utilisation

1. Placez `menu_template.html` et `injecteur_menu.py` dans le dossier contenant vos fichiers .html
2. Lancez le script Python :
   ```bash
   python injecteur_menu.py
   ```
3. Toutes vos pages auront un menu multilingue cohérent

## 📁 Structure recommandée

JusticeDMJ972Project/
├── index.html
├── index_en.html
├── index_es.html
├── contact.html
├── mur_de_memoire.html
├── assistant_juridique.html
├── temoignages_timeline.html
├── language_redirect.html
├── pages/                  # versions traduites (option)
└── assets/                 # fichiers images ou PDF
