
from pathlib import Path

menu = Path("menu_template.html").read_text(encoding="utf-8")

for html_file in Path(".").glob("*.html"):
    if html_file.name.startswith("menu") or "language_redirect" in html_file.name:
        continue
    content = html_file.read_text(encoding="utf-8")
    if "<nav" in content:
        continue
    updated = content.replace("<body>", f"<body>\n{menu}", 1)
    html_file.write_text(updated, encoding="utf-8")
    print(f"✅ Menu injecté dans {html_file.name}")
